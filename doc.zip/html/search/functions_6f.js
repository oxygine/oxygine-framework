var searchData=
[
  ['open',['open',['../namespaceoxygine_1_1file.html#aa996af03e94977cf40b1d569e7d7fed4',1,'oxygine::file']]]
];
