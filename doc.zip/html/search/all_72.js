var searchData=
[
  ['read',['read',['../namespaceoxygine_1_1file.html#ad3edf38d86746d3cd74e91ba28e9e38e',1,'oxygine::file::read(handle, void *dest, unsigned int size)'],['../namespaceoxygine_1_1file.html#a183a95e6f13d6dc7c0a9c489c79650b2',1,'oxygine::file::read(const char *file, buffer &amp;dest, error_policy ep=ep_show_error)'],['../namespaceoxygine_1_1file.html#a0c45c0f5edaff7b6938d3d0aafabe454',1,'oxygine::file::read(handle, buffer &amp;dest)']]],
  ['rectt',['RectT',['../classoxygine_1_1_rect_t.html',1,'oxygine']]],
  ['rectt_3c_20point_20_3e',['RectT&lt; Point &gt;',['../classoxygine_1_1_rect_t.html',1,'oxygine']]],
  ['rectt_3c_20vector2_20_3e',['RectT&lt; Vector2 &gt;',['../classoxygine_1_1_rect_t.html',1,'oxygine']]],
  ['ref_5fcounter',['ref_counter',['../classoxygine_1_1ref__counter.html',1,'oxygine']]],
  ['refholder',['RefHolder',['../classoxygine_1_1_ref_holder.html',1,'oxygine']]],
  ['registerresourcetype',['registerResourceType',['../classoxygine_1_1_resources.html#a973bbd984340167fa3160cf0191b3cdc',1,'oxygine::Resources']]],
  ['release',['release',['../classoxygine_1_1_renderer.html#af85f662f6eb9641a1b7ce2e1b6bde299',1,'oxygine::Renderer']]],
  ['removetweens',['removeTweens',['../classoxygine_1_1_actor.html#ac45fc08b910d79a9c53bf0031e6b5f56',1,'oxygine::Actor']]],
  ['render',['render',['../classoxygine_1_1_actor.html#aee39f95a3264349b3dc5fab1a3530dca',1,'oxygine::Actor::render()'],['../classoxygine_1_1_clip_rect_actor.html#ad5925949af6cf420e1550c544529583c',1,'oxygine::ClipRectActor::render()'],['../classoxygine_1_1_debug_actor.html#a3a815cb7e169e56dae988ec5f3a9c9db',1,'oxygine::DebugActor::render()'],['../classoxygine_1_1_tree_inspector.html#a285ed4e7aed752939f6d1893dd8c25cc',1,'oxygine::TreeInspector::render()'],['../classoxygine_1_1_root_actor.html#a80cb0a00c617ac783805627991a5a699',1,'oxygine::RootActor::render()'],['../classoxygine_1_1_masked_actor.html#af820ffef1e450c9c2a5f4aef270e18a0',1,'oxygine::MaskedActor::render()']]],
  ['renderer',['Renderer',['../classoxygine_1_1_renderer.html',1,'oxygine']]],
  ['renderstate',['RenderState',['../classoxygine_1_1_render_state.html',1,'oxygine']]],
  ['resanim',['ResAnim',['../classoxygine_1_1_res_anim.html',1,'oxygine']]],
  ['resatlas',['ResAtlas',['../classoxygine_1_1_res_atlas.html',1,'oxygine']]],
  ['resbuffer',['ResBuffer',['../classoxygine_1_1_res_buffer.html',1,'oxygine']]],
  ['resfont',['ResFont',['../classoxygine_1_1_res_font.html',1,'oxygine']]],
  ['resfontbm',['ResFontBM',['../classoxygine_1_1_res_font_b_m.html',1,'oxygine']]],
  ['resource',['Resource',['../classoxygine_1_1_resource.html',1,'oxygine']]],
  ['resources',['Resources',['../classoxygine_1_1_resources.html',1,'oxygine']]],
  ['resstarlingatlas',['ResStarlingAtlas',['../classoxygine_1_1_res_starling_atlas.html',1,'oxygine']]],
  ['rootactor',['RootActor',['../classoxygine_1_1_root_actor.html',1,'oxygine']]]
];
