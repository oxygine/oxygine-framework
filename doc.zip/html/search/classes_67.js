var searchData=
[
  ['getset2args',['GetSet2Args',['../classoxygine_1_1_get_set2_args.html',1,'oxygine']]],
  ['getset2args1arg',['GetSet2Args1Arg',['../classoxygine_1_1_get_set2_args1_arg.html',1,'oxygine']]]
];
