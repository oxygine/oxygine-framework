var searchData=
[
  ['write',['write',['../namespaceoxygine_1_1file.html#a9d61376794d32fba2baa7480c83e9375',1,'oxygine::file::write(handle, const void *data, unsigned int size)'],['../namespaceoxygine_1_1file.html#a2179883f1e3baefb6faada0caf8ac986',1,'oxygine::file::write(const char *file, const buffer &amp;data, error_policy ep=ep_show_error)']]]
];
