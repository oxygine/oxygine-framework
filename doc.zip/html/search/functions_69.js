var searchData=
[
  ['init',['init',['../classoxygine_1_1_res_font_b_m.html#a94f24c72f6f0a6c75a3a6ca054011bd1',1,'oxygine::ResFontBM::init()'],['../classoxygine_1_1_root_actor.html#af7f460ba32d7bab64d646aab5a9b112e',1,'oxygine::RootActor::init()']]],
  ['initcoordinatesystem',['initCoordinateSystem',['../classoxygine_1_1_renderer.html#a26c280129d515aff9ff0163c0e56877f',1,'oxygine::Renderer']]],
  ['initialize',['initialize',['../classoxygine_1_1_renderer.html#a6c7266ac08c530583aa9aee90b12e6dd',1,'oxygine::Renderer']]],
  ['isdescendant',['isDescendant',['../classoxygine_1_1_actor.html#a99855c23f6ad719d7d7f33fe8ed8b60b',1,'oxygine::Actor']]],
  ['ison',['isOn',['../classoxygine_1_1_actor.html#ae940ff17bfb4f158413f4341e532a332',1,'oxygine::Actor::isOn()'],['../classoxygine_1_1_root_actor.html#a8ce25f0d0ee6cb8dad205c41602e509f',1,'oxygine::RootActor::isOn()'],['../classoxygine_1_1_text_actor.html#a22c5bc95285cd9026f4e37109673d846',1,'oxygine::TextActor::isOn()']]]
];
