var searchData=
[
  ['init',['init',['../classoxygine_1_1_res_font_b_m.html#a94f24c72f6f0a6c75a3a6ca054011bd1',1,'oxygine::ResFontBM::init()'],['../classoxygine_1_1_root_actor.html#af7f460ba32d7bab64d646aab5a9b112e',1,'oxygine::RootActor::init()']]],
  ['initialize',['initialize',['../classoxygine_1_1_renderer.html#a6c7266ac08c530583aa9aee90b12e6dd',1,'oxygine::Renderer']]],
  ['isdescendant',['isDescendant',['../classoxygine_1_1_actor.html#a99855c23f6ad719d7d7f33fe8ed8b60b',1,'oxygine::Actor']]]
];
