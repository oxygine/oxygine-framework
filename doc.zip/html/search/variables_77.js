var searchData=
[
  ['white',['white',['../classoxygine_1_1_renderer.html#aa7255f69699a1bb72f74a058c42c24a7',1,'oxygine::Renderer']]]
];
