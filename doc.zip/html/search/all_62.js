var searchData=
[
  ['batch',['batch',['../structoxygine_1_1batch.html',1,'oxygine']]],
  ['begin',['begin',['../classoxygine_1_1_renderer.html#a445d1c906cf4282b6f2bc30c88160dca',1,'oxygine::Renderer']]],
  ['box9sprite',['Box9Sprite',['../classoxygine_1_1_box9_sprite.html',1,'oxygine']]],
  ['buffer',['buffer',['../classoxygine_1_1file_1_1buffer.html',1,'oxygine::file']]],
  ['button',['Button',['../classoxygine_1_1_button.html',1,'oxygine']]]
];
