package org.libsdl.app;

/**
    OxygineActivity
*/
public class OxygineActivity extends SDLActivity 
{

}
