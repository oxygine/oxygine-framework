package org.libsdl.app;

/**
    OxygineActivity
*/
public class Match3QuestActivity extends OxygineActivity 
{

}
