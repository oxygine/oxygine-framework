var searchData=
[
  ['registerresourcetype',['registerResourceType',['../classoxygine_1_1_resources.html#a973bbd984340167fa3160cf0191b3cdc',1,'oxygine::Resources']]],
  ['release',['release',['../classoxygine_1_1_renderer.html#af85f662f6eb9641a1b7ce2e1b6bde299',1,'oxygine::Renderer']]],
  ['removetweens',['removeTweens',['../classoxygine_1_1_actor.html#ac45fc08b910d79a9c53bf0031e6b5f56',1,'oxygine::Actor']]],
  ['render',['render',['../classoxygine_1_1_actor.html#aee39f95a3264349b3dc5fab1a3530dca',1,'oxygine::Actor::render()'],['../classoxygine_1_1_clip_rect_actor.html#ad5925949af6cf420e1550c544529583c',1,'oxygine::ClipRectActor::render()'],['../classoxygine_1_1_debug_actor.html#a3a815cb7e169e56dae988ec5f3a9c9db',1,'oxygine::DebugActor::render()'],['../classoxygine_1_1_masked_sprite.html#a61d300d08c630e5467761706f6654a12',1,'oxygine::MaskedSprite::render()'],['../classoxygine_1_1_stage.html#a189e2a27916bad88c832c6efdf783362',1,'oxygine::Stage::render(Renderer &amp;r)'],['../classoxygine_1_1_stage.html#a79e917ee0dbcd82eaffc1ac7e11375b4',1,'oxygine::Stage::render(const Color &amp;clearColor, const Rect &amp;viewport)']]],
  ['reset',['reset',['../classoxygine_1_1_renderer.html#a64c5d0c913241d2188dd5c789c81390e',1,'oxygine::Renderer::reset()'],['../classoxygine_1_1_tween.html#a4c32ac051dd3c4bf5e17890076bbd7fe',1,'oxygine::Tween::reset()']]],
  ['resetsettings',['resetSettings',['../classoxygine_1_1_renderer.html#aaa010615c1acda86b7656fbae9c042a7',1,'oxygine::Renderer']]],
  ['restore',['restore',['../classoxygine_1_1_renderer.html#acecadc1eb69470403d4346ab4cb423e6',1,'oxygine::Renderer']]]
];
