var searchData=
[
  ['appname',['appName',['../structoxygine_1_1core_1_1init__desc.html#a4750b5fc718c31b7235ae5bb445b4415',1,'oxygine::core::init_desc']]]
];
