var searchData=
[
  ['_5fhandle_5f',['_handle_',['../structoxygine_1_1file_1_1__handle__.html',1,'oxygine::file']]]
];
