#Videos

1. [Intro](https://www.youtube.com/watch?v=LGMrmZXjFY0&feature=youtu.be)
2. [Emscripten](https://www.youtube.com/watch?v=KX1v3bGCnJc&feature=youtu.be)
3. [Create Vistual Studio project](https://www.youtube.com/watch?v=kiRtI76rAxs&feature=youtu.be) 
4. [Setup Vistual Studio project](https://www.youtube.com/watch?v=pgk-kT_UbPg&feature=youtu.be)
5. [Create own Button class with image](https://www.youtube.com/watch?v=g-EegpfEEQU)
6. [Add animation and overload virtual Update method](https://youtu.be/OkkarSCntl0)
