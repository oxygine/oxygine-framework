#Colors table

Colors are available in the class **Color**.

![](img/colors.png)