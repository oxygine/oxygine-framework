#oxygine-billing 
In development. Available only Android Google Play version.
https://bitbucket.org/oxygine/oxygine-billing