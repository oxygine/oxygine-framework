#oxygine-billing 
In development. 

Available markets:

- google play
- amazon

https://github.com/oxygine/oxygine-billing