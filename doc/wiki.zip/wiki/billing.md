#oxygine-billing 
In development. 

Available markets:

- google play
- amazon

https://bitbucket.org/oxygine/oxygine-billing