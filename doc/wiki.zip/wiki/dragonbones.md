#DragonBones

[DragonBones](http://dragonbones.effecthub.com) is the Open Source 2D skeleton animation solution.

![](img/dragonbones.png)

Oxygine library for playing DragonBones in development. [**See Online Demo**](http://oxygine.org/emscripten/DragonBones.html)